<!DOCTYPE html>    
<html>
    
    <head>
        <title><?php echo "Libreria online"?></title>
        <!--<link rel="stylesheet" href="css/libreria.css">-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            html,body{
        background-color: rgb(66,66,66);
        font-family: 'Open Sans', sans-serif;
        margin:0px;
        padding:0px; /*cornice*/
        }
        /*MAIN MENU*/
        .rettangolo{
            background-color:  rgb(123, 0, 0);
            width:100%;
            height:70px;
        }
        .titolo{/*TITOLO MANIN_MENU*/
            color: white;
            width:300px;
            float:left;
            margin-top:10px;/*SPOSTAMENTO TITOLO */
            margin-left:10px;
        }
        .main_menu_opzioni{
            float:right;
            margin-top:20px;/* SPOSTAMENTO*/
            margin-right:10px;
        }
        a{
            color:white;
            margin-right: 5px;
            text-decoration: none;/*tolgo la SOTTOLINEATURA*/
        }
        .op_selezionata{ /*quando seleziono l'opzione, mi viene sottolineata*/
            text-decoration: underline;
        }
        .clear{
            clear:both;
        }
        /*FINE MAIN MENU*/
        </style>

    </head>

    <!-- INIZIO PAGINA PER LIBRI -->
    <body><!-- inizio BODY -->
    <!-- suddivisioni -->
    <div class="main_menu"> 
        <div class="rettangolo">
            <h1 class="titolo">LIBRERIA ONLINE</h1>
            <ul class="main_menu_opzioni">
                <a href="libreria_contatti.php" >CONTATTI</a>
                <a href="libreria_news.php" class="op_selezionata">NEWS</a></li>
                <a href="libreria_chisiamo.php">CHI SIAMO</a>
                <a href="libreria_login.php">LOGIN</a>
            </ul>
        </div>
        <div class="clear"></div><!--coi FLOAT-->
    </div>
    <div class="header">

    </div>
    <div class="content">

    </div>
    <div class="footer">
    </div>
    <?php
    include("php/libreria.php");
    ?>
       
           
    </body>
</html>